CREATE FUNCTION nextval(seq_name VARCHAR(50))
  RETURNS INT
  BEGIN
     UPDATE sequence
          SET current_value = current_value + increment 
          WHERE name = seq_name; 
     RETURN currval(seq_name); 
END;
