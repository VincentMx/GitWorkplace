CREATE FUNCTION setval(seq_name VARCHAR(50), value INT)
  RETURNS INT
  BEGIN
     UPDATE sequence
          SET current_value = value 
          WHERE name = seq_name; 
     RETURN currval(seq_name); 
END;
