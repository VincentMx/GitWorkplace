CREATE PROCEDURE sss()
  BEGIN
	#Routine body goes here...
DECLARE

  vv varchar(50);
	#Routine body goes here...
  select cl_cph into vv from cl_xx where skey='01';
  insert into park_sf(skey,BZ) values('01',vv);
  commit;
  
END;
